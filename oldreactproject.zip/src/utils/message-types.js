export const messageTypes = {
  'change:projects': 'change:projects',
  'change:units': 'change:units',
  'change:staging': 'change:staging',
};
